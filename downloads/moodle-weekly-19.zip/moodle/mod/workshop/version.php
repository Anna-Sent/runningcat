<?php // $Id: version.php,v 1.36.2.2 2009/11/12 15:47:08 mudrd8mz Exp $

////////////////////////////////////////////////////////////////////////////////
//  Code fragment to define the module version etc.
//  This fragment is called by /admin/index.php
////////////////////////////////////////////////////////////////////////////////

$module->version  = 2007101510;
$module->requires = 2007101509;  // Requires this Moodle version
$module->cron     = 60;

?>
