<?php //$Id: config.php,v 1.1 2005/06/27 07:28:19 bobopinna Exp $
//
// Optional course format configuration file
//
// This file contains any specific configuration settings for the
// social format.
//
// The default blocks layout for this course format:
    $format['defaultblocks'] = 'participants,social_activities,admin,course_list:'.
                               'news_items,recent_activity,calendar_upcoming';

?>
