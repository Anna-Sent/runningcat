.block_login .logintable {
  text-align:center;
}

.block_login .loginform {
  display:inline;
}

.block_login .loginform .fld input {
  width:5em;
}

.block_login .loginform label {
  padding-right: 4px;
}

.block_login .loginform div {
  margin:0.3em 0.8em;
  text-align:right;
  display:block;
}

.block_login .loginform div.c1.btn {
  text-align:center;
}
